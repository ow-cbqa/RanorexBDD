﻿namespace TechTalk.SpecFlow.Utils
{
    public enum CodeDomProviderLanguage
    {
        CSharp,
        VB,
        Other
    }
}