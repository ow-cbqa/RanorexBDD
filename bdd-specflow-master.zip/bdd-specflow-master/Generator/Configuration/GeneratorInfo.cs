﻿using System;
using System.Linq;

namespace TechTalk.SpecFlow.Generator.Configuration
{
    public class GeneratorInfo
    {
        public Version GeneratorAssemblyVersion { get; set; }
        public Version GeneratorVersion { get; set; }
        public string GeneratorFolder { get; set; }
        public bool UsesPlugins { get; set; }
    }
}
