﻿namespace TechTalk.SpecFlow.Generator.Configuration
{
    public interface IGeneratorInfoProvider
    {
        GeneratorInfo GetGeneratorInfo();
    }
}