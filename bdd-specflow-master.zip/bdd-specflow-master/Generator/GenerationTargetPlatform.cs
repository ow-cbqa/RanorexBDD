﻿namespace TechTalk.SpecFlow.Generator
{
    public static class GenerationTargetPlatform
    {
        public const string DotNet = ".NET";
        public const string Mono = "Mono";
        public const string Silverlight = "Silverlight";
        public const string WindowsPhone = "WindowsPhone";
        public const string Moonlight = "Moonlight";
    }
}