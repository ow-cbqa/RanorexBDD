namespace TechTalk.SpecFlow.IdeIntegration.Install
{
    public enum IdeIntegration
    {
        Unknown,
        VisualStudio2008 = 1000,
        VisualStudio2010 = 2000,
        VisualStudio2012 = 3000,
        MonoDevelop = 4000,
        SharpDevelop = 5000
    }
}