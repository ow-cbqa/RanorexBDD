﻿namespace TechTalk.SpecFlow.Parser
{
    public enum GherkinBlockKeyword
    {
        Feature,
        Background,
        Scenario,
        ScenarioOutline,
        Examples
    }
}