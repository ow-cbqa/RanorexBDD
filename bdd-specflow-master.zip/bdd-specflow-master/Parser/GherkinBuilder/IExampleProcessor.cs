﻿namespace TechTalk.SpecFlow.Parser.GherkinBuilder
{
    internal interface IExampleProcessor
    {
        void ProcessExample(ExampleBuilder examplebuilder);
    }
}