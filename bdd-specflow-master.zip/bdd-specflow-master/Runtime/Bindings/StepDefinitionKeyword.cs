namespace TechTalk.SpecFlow.Bindings
{
    public enum StepDefinitionKeyword
    {
        Given = ScenarioBlock.Given,
        When = ScenarioBlock.When,
        Then = ScenarioBlock.Then,
        And = 4,
        But = 5
    }
}