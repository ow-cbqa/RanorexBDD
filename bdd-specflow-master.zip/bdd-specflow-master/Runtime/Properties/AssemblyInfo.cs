﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("TechTalk.SpecFlow")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("cba254bb-2476-4e96-9a9f-6db1a1b5eb62")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: AllowPartiallyTrustedCallers]

[assembly: InternalsVisibleTo("TechTalk.SpecFlow.RuntimeTests, PublicKey=00240000048000009400000006020000002400005253413100040000010001009BD35D42479A68A533445360CA3149C96BF112221527828DCCC15604830999FAD6391912EDBDF591531C4DE9C45E437A3F648A2A3722D04E5A02BECE96522C71060081A14E1E775DF4B6F84D6DB609E3A20D15956D3FEDBFD77B2A9B0D941ACABCBF7C26B87F5696FE4AADAACA69DCB84E7C733D5FF0E9ECEF46656D19BF52A2")]
