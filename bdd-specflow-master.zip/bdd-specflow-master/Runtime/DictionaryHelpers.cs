﻿namespace TechTalk.SpecFlow
{
//    public static class DictionaryHelpers
//    {
//        public static void Set<T>(this ScenarioContext scenarioContext, T data)
//        {
//            var id = typeof (T).ToString();
//            scenarioContext.Set(data, id);
//        }
//
//        public static void Set<T>(this ScenarioContext scenarioContext, T data, string id)
//        {
//            scenarioContext[id] = data;
//        }
//
//        public static T Get<T>(this ScenarioContext scenarioContext) where T : class
//        {
//            var id = typeof (T).ToString();
//            return scenarioContext.Get<T>(id);
//        }
//
//        public static T Get<T>(this ScenarioContext scenarioContext, string id) where T : class
//        {
//            return scenarioContext[id] as T;
//        }
//    }
}