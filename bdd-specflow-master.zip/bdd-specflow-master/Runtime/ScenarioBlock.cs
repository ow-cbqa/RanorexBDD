using System;
using System.Linq;

namespace TechTalk.SpecFlow
{
    public enum ScenarioBlock
    {
        None = 0,
        Given = 1,
        When = 2,
        Then = 3,
    }
}