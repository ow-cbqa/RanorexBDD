﻿namespace TechTalk.SpecFlow.Assist.ValueRetrievers
{
    internal class StringValueRetriever
    {
        public string GetValue(string value)
        {
            return value;
        }
    }
}