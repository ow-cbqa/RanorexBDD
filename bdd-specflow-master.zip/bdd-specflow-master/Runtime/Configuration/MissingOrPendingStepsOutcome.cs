namespace TechTalk.SpecFlow.Configuration
{
    public enum MissingOrPendingStepsOutcome
    {
        Pending,
        Inconclusive,
        Ignore,
        Error
    }
}