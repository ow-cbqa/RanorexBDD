using System;

namespace TechTalk.SpecFlow.UnitTestProvider
{
    public class MbUnit3RuntimeProvider : MbUnitRuntimeProvider
    {
    }
}