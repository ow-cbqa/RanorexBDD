﻿namespace TechTalk.SpecFlow.UnitTestProvider
{
    public class MsTest2010RuntimeProvider : MsTestRuntimeProvider
    {
        
    }
}