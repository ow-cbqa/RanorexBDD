﻿namespace TechTalk.SpecFlow
{
    public enum ProgrammingLanguage
    {
        Other,
        CSharp,
        VB,
        FSharp
    }
}